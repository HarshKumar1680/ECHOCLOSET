let express = require('express');
let path = require('path');
let app = express();

const PORT = 5001;


app.set('view engine', 'ejs');


app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));


app.listen(PORT, () => {
    console.log(`Server is connected to http://localhost:${PORT}`);
});



app.get('/', (req, res) => {
    res.render('homepage', { title: 'Main' }); 
});

app.get('/aboutus.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', `aboutus.html`));
});

app.get('/explore.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', `explore.html`));
});

app.get('/contactpage.html', (req, res) => {    
    res.sendFile(path.join(__dirname, 'views', `contactpage.html`));
});

app.get('/signin.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', `signin.html`));
});

app.get('/signup.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', `signup.html`));
});


