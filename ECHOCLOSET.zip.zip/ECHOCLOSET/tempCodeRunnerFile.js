let express = require('express');
let path = require('path');
let app = express();

const PORT = 3001;

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Set the views directory
app.set('views', path.join(__dirname, 'views'));

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Start the server
app.listen(PORT, () => {
    console.log(`Server is connected to http://localhost:${PORT}`);
});


// Define Routes
app.get('/', (req, res) => {
    res.render('homepage', { title: 'Main' }); // Render the homepage.ejs file
});

// Dynamic route to serve .html files if needed
app.get('/aboutus.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', `aboutus.html`));
});

