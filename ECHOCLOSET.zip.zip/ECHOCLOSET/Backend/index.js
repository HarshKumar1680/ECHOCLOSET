// index.js
const express = require('express');
const path = require('path');
const connectDB = require('./connect'); // Import MongoDB connection function
const User = require('./model'); // Import the User model

const app = express();

// Middleware
app.use(express.json()); // To parse JSON data

// Connect to MongoDB
connectDB();

// Serve static files (for front-end files like CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// Simple home route
app.get('/', (req, res) => {
  res.send('Welcome to EchoCloset Backend');
});

app.post('/signin', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Check if user exists in the database
    const user = await User.findOne({ username });

    if (!user) {
      return res.status(400).json({ msg: 'User not found' });
    }

    // Check if the password matches (this example assumes plain-text passwords)
    if (user.password !== password) {
      return res.status(400).json({ msg: 'Invalid password' });
    }

    // Successful sign-in
    return res.status(200).json({ msg: 'Sign-in successful', user });

  } catch (error) {
    console.error(error);
    res.status(500).json({ msg: 'Server error' });
  }
});

// Start the server
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
