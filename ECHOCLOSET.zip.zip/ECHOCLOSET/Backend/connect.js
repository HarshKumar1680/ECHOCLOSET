
const mongoose = require('mongoose');


const mongoURI = 'mongodb+srv://harsh:%40harsh9999hk@cluster0.5ub14.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

const connectDB = async () => {
  try {
    await mongoose.connect(mongoURI, {
      useNewUrlParser: true, 
      useUnifiedTopology: true, 
    });
    console.log('DB is connected');
  } catch (err) {
    console.error('DB connection error:', err);
    process.exit(1); 
  }
};

module.exports = connectDB;
